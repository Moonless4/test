import { useCallback, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import type { Product } from '../../lib/types';
import { useDragScroll } from '../../hooks/useDragScroll';
import ProductCard from './ProductCard';

/** Horizontally scrollable product rail with RTL-aware arrow controls. */
export default function ProductCarousel({ products }: { products: Product[] }) {
  const railRef = useRef<HTMLDivElement>(null);
  const railDrag = useDragScroll(railRef);

  const scrollByCards = useCallback((forward: boolean) => {
    const el = railRef.current;
    if (!el) return;
    const isRtl = getComputedStyle(el).direction === 'rtl';
    const step = Math.max(el.clientWidth * 0.7, 240);
    // RTL scroll offsets grow towards the start, so the sign flips.
    const delta = isRtl ? (forward ? -step : step) : forward ? step : -step;
    el.scrollBy({ left: delta, behavior: 'smooth' });
  }, []);

  const arrow =
    'flex h-10 w-10 items-center justify-center rounded-full border border-line bg-white text-black shadow-soft transition-all hover:bg-teal-800 hover:text-white';

  return (
    <div>
      {/* Kept in the flow so the arrows can never land on top of the section heading. */}
      <div className="mb-3 hidden items-center justify-end gap-2 sm:flex">
        <button
          type="button"
          aria-label="محصولات قبلی"
          className={arrow}
          onClick={() => scrollByCards(false)}
        >
          <ChevronRight className="h-5 w-5" />
        </button>
        <button
          type="button"
          aria-label="محصولات بعدی"
          className={arrow}
          onClick={() => scrollByCards(true)}
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
      </div>

      <div
        ref={railRef}
        {...railDrag}
        className="no-scrollbar -mx-4 flex cursor-grab snap-x snap-mandatory select-none gap-3.5 overflow-x-auto px-4 pb-2 active:cursor-grabbing [&_a]:cursor-grab sm:mx-0 sm:gap-5 sm:px-0"
      >
        {products.map((product) => (
          <div
            key={product.id}
            className="w-[46%] shrink-0 snap-start sm:w-[30%] md:w-[23%] lg:w-[calc((100%-100px)/6)]"
          >
            <ProductCard product={product} />
          </div>
        ))}
      </div>
    </div>
  );
}
